<?php get_header(); ?>
	<section class="primary">
		<?php get_template_part( 'template-parts/content', 'article-menu' ); ?>
		<div class="error-msg"></div>
	</section>
<?php
get_footer();