<div class="to-show clearfix">
	<span class="header">点滴</span>
	<article class="show-list">
		<a href=""></a>
		<!--<header class="list-title">买了张星巴克会员卡</header>-->
		<div class="block-snippet">在西北被摧残了一周多，本来去银川是最好的路线，但是想到黄沙漫天，只能选择换个路线，，和想象的一样，几...</div>
	</article>
	<article class="show-list">
		<a href=""></a>
		<!--<header class="list-title">买了张星巴克会员卡</header>-->
		<div class="block-snippet">在西北被摧残了一周多，本来去银川是最好的路线，但是想到黄沙漫天，只能选择换个路线，索性就来到了成都的一样，几...</div>
	</article>
	<article class="show-list">
		<a href=""></a>
		<!--<header class="list-title">买了张星巴克会员卡</header>-->
		<div class="block-snippet">在西北被摧残了一周多，本来去银川是最好的路线，但是想到黄沙漫天，只能选择换个索性就来到了成都，和想象的一样，几...</div>
	</article>
</div>